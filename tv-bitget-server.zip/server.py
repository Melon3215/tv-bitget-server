from dotenv import load_dotenv
load_dotenv()
from flask import Flask, request, jsonify
import hmac
import hashlib
import time
import requests
import json
import os

app = Flask(__name__)



API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")
API_PASSPHRASE = os.getenv("API_PASSPHRASE")

BASE_URL = "https://api.bitget.com"

def sign(message, secret):
    return hmac.new(secret.encode('utf-8'), message.encode('utf-8'), hashlib.sha256).hexdigest()

def place_order(symbol, side, price, size):
    timestamp = str(int(time.time() * 1000))
    method = "POST"
    request_path = "/api/v2/mix/order/place"
    body = {
        "symbol": symbol,
        "marginCoin": "USDT",
        "side": side,
        "orderType": "limit",
        "price": str(price),
        "size": str(size),
        "timeInForceValue": "normal",
        "posSide": "long" if side == "buy" else "short"
    }
    json_body = json.dumps(body)
    pre_hash = timestamp + method + request_path + json_body
    signature = sign(pre_hash, API_SECRET)

    headers = {
        "ACCESS-KEY": API_KEY,
        "ACCESS-SIGN": signature,
        "ACCESS-TIMESTAMP": timestamp,
        "ACCESS-PASSPHRASE": API_PASSPHRASE,
        "Content-Type": "application/json"
    }

    url = BASE_URL + request_path
    response = requests.post(url, headers=headers, data=json_body)
    return response.json()

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    print("Received data:", data)

    try:
        action = data['action']
        symbol = data['symbol']
        price = data['entry_price']
        size = data['size']
        side = "buy" if action == "buy" else "sell"
        result = place_order(symbol, side, price, size)
        return jsonify({"status": "success", "bitget_response": result}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
